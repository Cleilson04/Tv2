package com.example.kwitch

import androidx.compose.ui.graphics.Color

enum class Platform(val label: String, val color: Color) {
    KICK("Kick", Color(0xFF53FC18)),
    TWITCH("Twitch", Color(0xFF9146FF))
}

data class Channel(
    val platform: Platform,
    val name: String,
    val category: String,
    val viewers: Int,
    val hlsUrl: String
)

data class ChatMsg(val user: String, val text: String, val color: Color)

object Repository {
    private const val TEST_HLS =
        "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"
    private val categories = listOf("Just Chatting", "Games", "Música", "IRL")

    // Dados de exemplo. Depois trocamos pelas APIs reais da Kick e da Twitch.
    fun channels(p: Platform): List<Channel> = List(12) { i ->
        Channel(p, "Streamer ${i + 1}", categories[i % categories.size], 2000 - i * 130, TEST_HLS)
    }
}
