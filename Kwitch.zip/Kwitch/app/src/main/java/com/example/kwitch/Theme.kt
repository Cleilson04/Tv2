package com.example.kwitch

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp

@Composable
fun KwitchTheme(s: AppSettings, content: @Composable () -> Unit) {
    val accent = ACCENTS[s.accentIndex].second
    val d = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(d.density, d.fontScale * s.textScalePercent / 100f)
    ) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = accent,
                background = Color(0xFF0B0E0F),
                surface = Color(0xFF151A1C),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            ProvideTextStyle(TextStyle(fontFamily = FONTS[s.fontIndex].second)) {
                content()
            }
        }
    }
}

/** Botão/cartão que funciona com toque e com o controle remoto (destaca ao focar). */
@Composable
fun FocusBox(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val accent = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(12.dp)
    val borderColor = when {
        focused -> accent
        selected -> accent.copy(alpha = 0.7f)
        else -> Color(0xFF2A3236)
    }
    val borderWidth = if (focused) 3.dp else if (selected) 2.dp else 1.dp
    Box(
        modifier = modifier
            .background(if (selected) Color(0xFF1F2A2E) else Color(0xFF151A1C), shape)
            .border(borderWidth, borderColor, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        content = content
    )
}
