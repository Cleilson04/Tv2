package com.example.kwitch

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

val ACCENTS: List<Pair<String, Color>> = listOf(
    "Verde" to Color(0xFF53FC18),
    "Roxo" to Color(0xFF9146FF),
    "Azul" to Color(0xFF2D9CFF),
    "Laranja" to Color(0xFFFF8A00),
    "Rosa" to Color(0xFFFF4D8D),
    "Branco" to Color(0xFFFFFFFF)
)

val FONTS: List<Pair<String, FontFamily>> = listOf(
    "Padrão" to FontFamily.Default,
    "Serifa" to FontFamily.Serif,
    "Mono" to FontFamily.Monospace,
    "Cursiva" to FontFamily.Cursive
)

val CHAT_POSITIONS = listOf("Direita", "Embaixo", "Sobre o vídeo")

data class AppSettings(
    val accentIndex: Int = 0,
    val fontIndex: Int = 0,
    val cardWidthDp: Int = 220,
    val cardHeightDp: Int = 110,
    val textScalePercent: Int = 100,
    val chatEnabled: Boolean = true,
    val chatPosition: Int = 0,
    val chatSizePercent: Int = 30,
    val chatTextSp: Int = 14
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("kwitch", Context.MODE_PRIVATE)
    private val d = AppSettings()

    fun load() = AppSettings(
        accentIndex = prefs.getInt("accent", d.accentIndex).coerceIn(0, ACCENTS.lastIndex),
        fontIndex = prefs.getInt("font", d.fontIndex).coerceIn(0, FONTS.lastIndex),
        cardWidthDp = prefs.getInt("cardW", d.cardWidthDp),
        cardHeightDp = prefs.getInt("cardH", d.cardHeightDp),
        textScalePercent = prefs.getInt("textScale", d.textScalePercent),
        chatEnabled = prefs.getBoolean("chatOn", d.chatEnabled),
        chatPosition = prefs.getInt("chatPos", d.chatPosition).coerceIn(0, CHAT_POSITIONS.lastIndex),
        chatSizePercent = prefs.getInt("chatSize", d.chatSizePercent),
        chatTextSp = prefs.getInt("chatText", d.chatTextSp)
    )

    fun save(s: AppSettings) {
        prefs.edit()
            .putInt("accent", s.accentIndex)
            .putInt("font", s.fontIndex)
            .putInt("cardW", s.cardWidthDp)
            .putInt("cardH", s.cardHeightDp)
            .putInt("textScale", s.textScalePercent)
            .putBoolean("chatOn", s.chatEnabled)
            .putInt("chatPos", s.chatPosition)
            .putInt("chatSize", s.chatSizePercent)
            .putInt("chatText", s.chatTextSp)
            .apply()
    }
}
