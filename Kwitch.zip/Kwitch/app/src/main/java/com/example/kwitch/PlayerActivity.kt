package com.example.kwitch

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

class PlayerActivity : ComponentActivity() {
    private var exo: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val url = intent.getStringExtra("url") ?: run { finish(); return }
        val settings = SettingsStore(this).load()
        val player = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
        exo = player
        setContent {
            KwitchTheme(settings) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                    PlayerScreen(player, settings)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        exo?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        exo?.release()
        exo = null
    }
}

@Composable
fun PlayerScreen(exo: ExoPlayer, s: AppSettings) {
    val chat = (100 - s.chatSizePercent).toFloat()
    val video: @Composable (Modifier) -> Unit = { m ->
        AndroidView(
            modifier = m,
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = exo
                    useController = true
                }
            }
        )
    }
    if (!s.chatEnabled) {
        video(Modifier.fillMaxSize())
        return
    }
    when (s.chatPosition) {
        0 -> Row(Modifier.fillMaxSize()) {
            video(Modifier.weight(chat).fillMaxHeight())
            ChatPanel(Modifier.weight(s.chatSizePercent.toFloat()).fillMaxHeight(), s.chatTextSp, false)
        }
        1 -> Column(Modifier.fillMaxSize()) {
            video(Modifier.weight(chat).fillMaxWidth())
            ChatPanel(Modifier.weight(s.chatSizePercent.toFloat()).fillMaxWidth(), s.chatTextSp, false)
        }
        else -> Box(Modifier.fillMaxSize()) {
            video(Modifier.fillMaxSize())
            ChatPanel(
                Modifier
                    .align(Alignment.BottomEnd)
                    .fillMaxWidth((s.chatSizePercent / 100f).coerceIn(0.15f, 0.6f))
                    .fillMaxHeight(0.55f),
                s.chatTextSp,
                true
            )
        }
    }
}

private val SAMPLE_CHAT = listOf(
    ChatMsg("ana_live", "salve galera!", Color(0xFFFF4D8D)),
    ChatMsg("joaozin", "essa jogada foi insana", Color(0xFF2D9CFF)),
    ChatMsg("mod_carla", "lembrem de seguir o canal", Color(0xFF53FC18)),
    ChatMsg("pedro10", "kkkkkkk", Color(0xFFFF8A00)),
    ChatMsg("lu_gamer", "que qualidade de live", Color(0xFF9146FF)),
    ChatMsg("bia", "boa noite chat", Color(0xFFFF4D8D))
)

@Composable
fun ChatPanel(modifier: Modifier, textSp: Int, overlay: Boolean) {
    val messages = remember { mutableStateListOf<ChatMsg>() }
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) {
        var i = 0
        while (true) {
            messages.add(SAMPLE_CHAT[i % SAMPLE_CHAT.size])
            i++
            if (messages.size > 40) messages.removeAt(0)
            delay(1500)
        }
    }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }
    val bg = if (overlay) Color(0x99000000) else Color(0xFF101416)
    Column(modifier.background(bg)) {
        Text(
            "Chat (exemplo)",
            color = Color.Gray,
            fontSize = 11.sp,
            modifier = Modifier.padding(start = 8.dp, top = 6.dp)
        )
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(8.dp)) {
            items(messages) { m ->
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = m.color, fontWeight = FontWeight.Bold)) { append(m.user) }
                        append(": " + m.text)
                    },
                    fontSize = textSp.sp,
                    color = Color.White,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}
