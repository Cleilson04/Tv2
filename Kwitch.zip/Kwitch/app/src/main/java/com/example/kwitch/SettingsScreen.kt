package com.example.kwitch

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(s: AppSettings, onChange: (AppSettings) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Section("Cor de destaque") }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ACCENTS.forEachIndexed { i, pair ->
                    FocusBox(
                        onClick = { onChange(s.copy(accentIndex = i)) },
                        selected = s.accentIndex == i,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(Modifier.fillMaxSize().padding(8.dp).background(pair.second, CircleShape))
                    }
                }
            }
        }

        item { Section("Fonte") }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FONTS.forEachIndexed { i, pair ->
                    FocusBox(onClick = { onChange(s.copy(fontIndex = i)) }, selected = s.fontIndex == i) {
                        Text(
                            pair.first,
                            fontFamily = pair.second,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }

        item { Section("Tamanhos") }
        item {
            Stepper(
                "Largura do card", "${s.cardWidthDp} dp",
                { onChange(s.copy(cardWidthDp = (s.cardWidthDp - 20).coerceAtLeast(140))) },
                { onChange(s.copy(cardWidthDp = (s.cardWidthDp + 20).coerceAtMost(360))) }
            )
        }
        item {
            Stepper(
                "Altura do card", "${s.cardHeightDp} dp",
                { onChange(s.copy(cardHeightDp = (s.cardHeightDp - 10).coerceAtLeast(70))) },
                { onChange(s.copy(cardHeightDp = (s.cardHeightDp + 10).coerceAtMost(220))) }
            )
        }
        item {
            Stepper(
                "Tamanho do texto", "${s.textScalePercent}%",
                { onChange(s.copy(textScalePercent = (s.textScalePercent - 10).coerceAtLeast(80))) },
                { onChange(s.copy(textScalePercent = (s.textScalePercent + 10).coerceAtMost(150))) }
            )
        }

        item { Section("Chat") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FocusBox(onClick = { onChange(s.copy(chatEnabled = true)) }, selected = s.chatEnabled) {
                    Text("Ligado", Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                }
                FocusBox(onClick = { onChange(s.copy(chatEnabled = false)) }, selected = !s.chatEnabled) {
                    Text("Desligado", Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                }
            }
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CHAT_POSITIONS.forEachIndexed { i, name ->
                    FocusBox(onClick = { onChange(s.copy(chatPosition = i)) }, selected = s.chatPosition == i) {
                        Text(name, Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                    }
                }
            }
        }
        item {
            Stepper(
                "Tamanho do chat", "${s.chatSizePercent}%",
                { onChange(s.copy(chatSizePercent = (s.chatSizePercent - 5).coerceAtLeast(20))) },
                { onChange(s.copy(chatSizePercent = (s.chatSizePercent + 5).coerceAtMost(50))) }
            )
        }
        item {
            Stepper(
                "Texto do chat", "${s.chatTextSp} sp",
                { onChange(s.copy(chatTextSp = (s.chatTextSp - 2).coerceAtLeast(10))) },
                { onChange(s.copy(chatTextSp = (s.chatTextSp + 2).coerceAtMost(26))) }
            )
        }

        item {
            FocusBox(onClick = { onChange(AppSettings()) }) {
                Text("Restaurar padrão", Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
            }
        }
        item { Box(Modifier.size(24.dp)) }
    }
}

@Composable
private fun Section(title: String) {
    Text(title, color = MaterialTheme.colorScheme.primary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun Stepper(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        FocusBox(onClick = onMinus, modifier = Modifier.size(48.dp)) {
            Text("-", modifier = Modifier.align(Alignment.Center), fontSize = 22.sp)
        }
        Text(value, modifier = Modifier.width(84.dp), textAlign = TextAlign.Center, color = Color.White)
        FocusBox(onClick = onPlus, modifier = Modifier.size(48.dp)) {
            Text("+", modifier = Modifier.align(Alignment.Center), fontSize = 22.sp)
        }
    }
}
