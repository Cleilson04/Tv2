package com.example.kwitch

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = SettingsStore(this)
        setContent {
            var settings by remember { mutableStateOf(store.load()) }
            KwitchTheme(settings) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    HomeScreen(
                        s = settings,
                        onChange = { settings = it; store.save(it) },
                        onOpen = { ch ->
                            startActivity(
                                Intent(this@MainActivity, PlayerActivity::class.java)
                                    .putExtra("url", ch.hlsUrl)
                                    .putExtra("title", "${ch.platform.label} · ${ch.name}")
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(s: AppSettings, onChange: (AppSettings) -> Unit, onOpen: (Channel) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val accent = MaterialTheme.colorScheme.primary
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp)) {
        Text("Kwitch", color = accent, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Kick", "Twitch", "Config").forEachIndexed { i, name ->
                FocusBox(onClick = { tab = i }, selected = tab == i) {
                    Text(
                        name,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                        fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        if (tab == 2) {
            SettingsScreen(s, onChange)
        } else {
            val platform = if (tab == 0) Platform.KICK else Platform.TWITCH
            val channels = remember(platform) { Repository.channels(platform) }
            LazyVerticalGrid(
                columns = GridCells.Adaptive(s.cardWidthDp.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(channels) { ch -> ChannelCard(ch, s, onOpen) }
            }
        }
    }
}

@Composable
fun ChannelCard(ch: Channel, s: AppSettings, onOpen: (Channel) -> Unit) {
    FocusBox(
        onClick = { onOpen(ch) },
        modifier = Modifier.fillMaxWidth().height(s.cardHeightDp.dp)
    ) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(ch.platform.color, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(ch.platform.label.uppercase(), fontSize = 11.sp, color = ch.platform.color)
                Spacer(Modifier.weight(1f))
                Text("${ch.viewers}", fontSize = 11.sp, color = Color.Gray)
            }
            Column {
                Text(
                    ch.name, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    ch.category, fontSize = 13.sp, color = Color.Gray,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
