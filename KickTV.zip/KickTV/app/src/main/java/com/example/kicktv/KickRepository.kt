package com.example.kicktv

/**
 * Camada de dados. Hoje retorna dados de exemplo.
 * Troque pela integração com a API oficial da Kick (OAuth) quando estiver pronto.
 */
object KickRepository {
    private const val TEST_HLS =
        "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"

    suspend fun liveChannels(): List<Channel> = List(12) { i ->
        Channel(
            slug = "canal$i",
            title = "Canal de exemplo $i",
            category = if (i % 2 == 0) "Just Chatting" else "Games",
            viewers = 1000 - i * 50,
            hlsUrl = TEST_HLS
        )
    }
}
