package com.example.kicktv

data class Channel(
    val slug: String,
    val title: String,
    val category: String,
    val viewers: Int,
    val hlsUrl: String
)
